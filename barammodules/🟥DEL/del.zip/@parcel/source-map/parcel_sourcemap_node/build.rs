extern crate napi_build;

fn main() {
    napi_build::setup();
}
