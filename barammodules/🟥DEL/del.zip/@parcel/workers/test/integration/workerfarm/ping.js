function run() {
  return 'pong';
}

exports.run = run;
