import test from 'test';
import component from './component';

/**
 * This is a comment
 */
import Tooltip from '../tooltip';
import VisuallyHidden from '../visually-hidden';

/**
 * This is another comment
 */
import {Label} from './label';
