// package intro
// module intro
require('./module-a.js');
require('./module-b.js');
// module outro

// module intro
console.log('hi'); // eslint-disable-line no-console
// module outro
// package outro
