function hello(){var l="Hello",o="world";console.log(l+" "+o+"!")}hello();
//# sourceMappingURL=file://referenced-min.js.map
