function hello(){var l="Hello",o="world";console.log(l+" "+o+"!")}hello();
//# sourceMappingURL=source-root.js.map
