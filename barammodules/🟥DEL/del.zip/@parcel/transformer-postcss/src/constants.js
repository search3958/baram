// @flow

export const POSTCSS_RANGE = '^8.2.1';
