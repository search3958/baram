# @octokit/openapi-types

> Generated TypeScript definitions based on GitHub's OpenAPI spec

This package is continously updated based on [GitHub's OpenAPI specification](https://github.com/github/rest-api-description/)

## Usage

```ts
import { components } from "@octokit/openapi-types";

type Repository = components["schemas"]["full-repository"];
```

## License

[MIT](LICENSE)
