import { EndpointInterface, RequestInterface, RequestParameters } from "@octokit/types";
export default function withDefaults(oldEndpoint: EndpointInterface, newDefaults: RequestParameters): RequestInterface;
