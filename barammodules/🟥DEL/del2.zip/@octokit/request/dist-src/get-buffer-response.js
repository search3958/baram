export default function getBufferResponse(response) {
    return response.arrayBuffer();
}
