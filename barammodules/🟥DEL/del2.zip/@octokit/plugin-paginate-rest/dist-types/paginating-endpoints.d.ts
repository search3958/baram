import { PaginatingEndpoints } from "./generated/paginating-endpoints";
export { paginatingEndpoints } from "./generated/paginating-endpoints";
export declare function isPaginatingEndpoint(arg: unknown): arg is keyof PaginatingEndpoints;
