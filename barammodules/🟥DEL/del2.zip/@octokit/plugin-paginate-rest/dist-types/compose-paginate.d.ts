import { ComposePaginateInterface } from "./types";
export declare const composePaginateRest: ComposePaginateInterface;
