export declare const VERSION = "18.12.0";
