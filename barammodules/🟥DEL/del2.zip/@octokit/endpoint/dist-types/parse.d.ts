import { EndpointDefaults, RequestOptions } from "@octokit/types";
export declare function parse(options: EndpointDefaults): RequestOptions;
