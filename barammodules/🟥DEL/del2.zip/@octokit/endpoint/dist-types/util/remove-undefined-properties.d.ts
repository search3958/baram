export declare function removeUndefinedProperties(obj: any): any;
