export declare function lowercaseKeys(object?: {
    [key: string]: any;
}): {
    [key: string]: any;
};
