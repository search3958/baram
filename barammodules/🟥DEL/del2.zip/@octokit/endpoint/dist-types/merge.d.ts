import { EndpointDefaults, RequestParameters, Route } from "@octokit/types";
export declare function merge(defaults: EndpointDefaults | null, route?: Route | RequestParameters, options?: RequestParameters): EndpointDefaults;
