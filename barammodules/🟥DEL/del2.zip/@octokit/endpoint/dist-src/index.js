import { withDefaults } from "./with-defaults";
import { DEFAULTS } from "./defaults";
export const endpoint = withDefaults(null, DEFAULTS);
