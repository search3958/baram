const VERSION = "6.41.0";

export { VERSION };
//# sourceMappingURL=index.js.map
