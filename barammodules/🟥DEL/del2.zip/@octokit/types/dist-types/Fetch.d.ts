/**
 * Browser's fetch method (or compatible such as fetch-mock)
 */
export declare type Fetch = any;
