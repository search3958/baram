export declare const VERSION = "6.41.0";
