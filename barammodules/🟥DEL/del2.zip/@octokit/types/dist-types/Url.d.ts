/**
 * Relative or absolute URL. Examples: `'/orgs/{org}'`, `https://example.com/foo/bar`
 */
export declare type Url = string;
