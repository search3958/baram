'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const VERSION = "6.41.0";

exports.VERSION = VERSION;
//# sourceMappingURL=index.js.map
