# Installation
> `npm install --save @types/shelljs`

# Summary
This package contains type definitions for ShellJS (http://shelljs.org).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/shelljs.

### Additional Details
 * Last updated: Thu, 13 Jan 2022 04:01:33 GMT
 * Dependencies: [@types/glob](https://npmjs.com/package/@types/glob), [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Niklas Mollenhauer](https://github.com/nikeee), [Vojtech Jasny](https://github.com/voy), [George Kalpakas](https://github.com/gkalpak), [Paul Huynh](https://github.com/pheromonez), [Alexander Futász](https://github.com/aldafu), [ExE Boss](https://github.com/ExE-Boss), and [Mirco Sanguineti](https://github.com/msanguineti).
