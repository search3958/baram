# Monaco LSP Client

Provides a Language Server Protocol (LSP) client for the Monaco Editor.

This package is in alpha stage and might contain many bugs.
