import * as css from './css/register';
import * as html from './html/register';
import * as json from './json/register';
import * as typescript from './typescript/register';

export { css, html, json, typescript };
