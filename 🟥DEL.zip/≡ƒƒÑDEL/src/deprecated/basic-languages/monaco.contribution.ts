export * from '../../languages/definitions/register.all';
