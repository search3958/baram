import 'monaco-editor-core/esm/vs/editor/contrib/placeholderText/browser/placeholderText.contribution';
