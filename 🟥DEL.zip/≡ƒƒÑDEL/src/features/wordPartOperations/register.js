import 'monaco-editor-core/esm/vs/editor/contrib/wordPartOperations/browser/wordPartOperations';
