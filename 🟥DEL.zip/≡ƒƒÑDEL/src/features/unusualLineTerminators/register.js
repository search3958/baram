import 'monaco-editor-core/esm/vs/editor/contrib/unusualLineTerminators/browser/unusualLineTerminators';
