import 'monaco-editor-core/esm/vs/editor/contrib/inlineProgress/browser/inlineProgress';
