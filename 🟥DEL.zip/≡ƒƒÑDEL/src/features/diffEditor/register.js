import 'monaco-editor-core/esm/vs/editor/browser/widget/diffEditor/diffEditor.contribution';
