import 'monaco-editor-core/esm/vs/editor/contrib/smartSelect/browser/smartSelect';
