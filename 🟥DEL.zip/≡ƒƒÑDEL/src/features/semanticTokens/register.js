import 'monaco-editor-core/esm/vs/editor/contrib/semanticTokens/browser/viewportSemanticTokens';
