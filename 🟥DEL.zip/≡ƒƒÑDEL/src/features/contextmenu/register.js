import 'monaco-editor-core/esm/vs/editor/contrib/contextmenu/browser/contextmenu';
