import 'monaco-editor-core/esm/vs/editor/standalone/browser/iPadShowKeyboard/iPadShowKeyboard';
