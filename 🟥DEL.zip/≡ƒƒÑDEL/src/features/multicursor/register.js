import 'monaco-editor-core/esm/vs/editor/contrib/multicursor/browser/multicursor';
