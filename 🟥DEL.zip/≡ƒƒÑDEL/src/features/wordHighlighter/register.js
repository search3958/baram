import 'monaco-editor-core/esm/vs/editor/contrib/wordHighlighter/browser/wordHighlighter';
