import 'monaco-editor-core/esm/vs/editor/contrib/bracketMatching/browser/bracketMatching';
