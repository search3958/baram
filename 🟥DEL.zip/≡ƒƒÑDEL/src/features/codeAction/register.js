import 'monaco-editor-core/esm/vs/editor/contrib/codeAction/browser/codeActionContributions';
