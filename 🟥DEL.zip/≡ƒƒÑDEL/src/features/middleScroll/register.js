import 'monaco-editor-core/esm/vs/editor/contrib/middleScroll/browser/middleScroll.contribution';
