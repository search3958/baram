import 'monaco-editor-core/esm/vs/editor/contrib/format/browser/formatActions';
